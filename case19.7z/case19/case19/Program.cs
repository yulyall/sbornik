﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace case19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int k;
            Console.Write("Введите год :");
            string s = Console.ReadLine();
            int N = Convert.ToInt32(s);
            k = N % 60;
            switch (k / 12)
            {
                case 0: s = "красн"; break;
                case 1: s = "желт"; break;
                case 2: s = "зелен"; break;
                case 3: s = "бел"; break;
                case 4: s = "черн"; break;
            }
            switch (k % 12)
            {
                case 0: s += "ая обезьяна"; break;
                case 1: s += "ая курица"; break;
                case 2: s += "ая собака"; break;
                case 3: s += "ая свинья"; break;
                case 4: s += "ая овца"; break;
                case 5: s += "ая змея"; break;
                case 6: s += "ая корова"; break;
                case 7: s += "ый заяц"; break;
                case 8: s += "ый дракон"; break;
                case 9: s += "ый тигр"; break;
                case 10: s += "ая крыса"; break;
                case 11: s += "ая лошадь"; break;
            }
            Console.WriteLine(" {0} ", s);
            Console.ReadLine();

        }
    }
}
