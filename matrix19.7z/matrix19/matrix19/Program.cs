﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace matrix19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Int32[][] m = new Int32[][]
            {
                new Int32[]{2,3,6},
                new Int32[]{7,8,9},
                new Int32[]{1,1,0}
            };
            Console.WriteLine(f(m));
            Console.ReadLine();
        }
        static String f(Int32[][] m)
        {
            return m
                .Select(i => i.Aggregate("", (a, b) => a + "+" + b).Substring(1)
                        + "=" + i.Sum().ToString())
                .Aggregate("", (a, b) => a + "\n" + b);
        }
    }
}
