﻿using System;
using System.Linq;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] agrs)
        {
            double[,] arr = { { 1, 10 }, { 2, 20 }, { 3, 30 } };
            int s = 5;
            double sum3 = 0, sumS = 0;
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                sum3 += arr[i, 2];
                sumS += arr[i, s];
            }
            Console.WriteLine($"Сумма второй строки: {sum3}");
            Console.WriteLine($"Сумма {s} столбца: {sumS}");

        }

    }
    
}
