﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;
            int d;
            int n;
            Console.WriteLine("Введите значение а:");
            a = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Введите значение b");
            b = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Введите значение с:");
            c = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Введите значение d:");
            d = Convert.ToInt16(Console.ReadLine());
            if (a == b && b == c) Console.WriteLine(n = 1);
            else if (a == b && a == d) Console.WriteLine(n = 2);
            else if (a == c && a == d) Console.WriteLine(n = 3);
            else if (b == d && b == d) Console.WriteLine(n = 4);
            else Console.WriteLine(n = 5);
            Console.ReadKey();
        }
    }
}
