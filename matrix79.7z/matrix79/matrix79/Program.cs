﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace matrix79
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите N");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите M");
            int m = int.Parse(Console.ReadLine());
            int i, j;
            int[,] massiv = new int[n, m];

            for (i = 0; i < n; i++)                                // заполняем массив в ручную
            {
                for (j = 0; j < m; j++)
                {
                    Console.Write("Massiv[{0},{1}] ", i, j);
                    massiv[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("Исходный массив");
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < m; j++)
                {
                    Console.Write(" {0} ", massiv[i, j]);
                }
                Console.WriteLine();
            }
            int flag = 1;
            while (flag == 1)
            {
                flag = 0;
                for (i = 0; i < n - 1; i++)
                {
                    int max = 0;
                    int max1 = 0;
                    for (j = 0; j < m; j++)
                    {
                        if (massiv[j, i] > max)
                        {
                            max = massiv[j, i];
                        }
                        if (massiv[j, i + 1] > max1)
                        {
                            max1 = massiv[j, i + 1];
                        }
                    }
                    if (max > max1)
                    {
                        for (j = 0; j < m; j++)
                        {
                            int tmp = massiv[j, i];
                            massiv[j, i] = massiv[j, i + 1];
                            massiv[j, i + 1] = tmp;
                        }
                        flag = 1;
                    }
                }
            }
            Console.WriteLine("Преобразованный массив");
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < m; j++)
                {
                    Console.Write(" {0} ", massiv[i, j]);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
