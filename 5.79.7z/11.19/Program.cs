﻿using System;

namespace _11._19
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Введите первое значение х");
            double x1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Введите второе значение х");
            double x2 = double.Parse(Console.ReadLine());

            double s = Math.Cos(x1) - Math.Cos(x2);

            Console.WriteLine($"Приближенная площадь одной арки синусоиды~ {s}");


        }
    }
}
