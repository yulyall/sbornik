﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var n = 6;
            var result = n;
            while (n > 2)
            {
                result *= n -= 2;
            }
            Console.WriteLine(result);
        }
    }
}
