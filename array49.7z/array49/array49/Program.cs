﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array49
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите размерность массива: ");
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine("Проверка массива на перестановку. \n"
                    + "Введите {0} элементов массива: ", N);
            int[] A = new int[N]; // Создадим массив А размера N
            for (int X = 0; X < N; X++)
                A[X] = int.Parse(Console.ReadLine());
            //        A = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            for (int T = 1; T <= N; T++) // Цикл создаёт числа перестановки 
                                         //для сравнения
            {
                int coincidence = 0; // Совпадение числа в массиве 
                                     //с числом перестановки
                int i = 0; // Элемент массива
                int Y = 0; // Переменная выхода из циклов
                for (; i < N; i++) // Цикл поэлементно опрашивает массив А

                {
                    if (T == A[i]) coincidence++;

                    if ((coincidence > 1) || ((A[i] > N) || (A[i] == 0)))
                    {

                        Console.WriteLine("Недопустимый элемент: " + A[i]);
                        Y = 1;
                        break;
                    }

                }
                if (Y == 1) break;

                if (T == N) Console.WriteLine("Массив является перестановкой");
            }
            Console.ReadLine();
        }
    }
}
