﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proc19
{
    internal class Program
    {
        static double Ring(double r1, double r2)
        {
            return Math.PI * (r1 + r2) * (r1 - r2);
        }
        static void Main(string[] args)
        {
            for (int i = 1; i < 4; i++)
            {
                Console.Write("Введите внешний радиус {0} кольца: ", i);
                double r1 = double.Parse(Console.ReadLine());
                Console.Write("Введите внутренний радиус {0} кольца: ", i);
                double r2 = double.Parse(Console.ReadLine());
                Console.WriteLine("Площадь {0} кольца равна {1:F3}\n", i, Ring(r1, r2));
            }
        }
    }
}
