﻿using System;

namespace ConsoleApp27
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            string n = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Введите первое искомое число");
            string ch1 = Console.ReadLine();
            Console.WriteLine("Введите второе искомое число");
            string ch2 = Console.ReadLine();

            Console.WriteLine("Введите третье искомое число");
            string ch3 = Console.ReadLine();


            int count1 = 0;
            char[] mas1 = n.ToCharArray();
            foreach (var s in mas1)
            {
                if (s == char.Parse(ch1)) count1++;
            }
            int count2 = 0;
            char[] mas2 = n.ToCharArray();
            foreach (var s in mas2)
            {
                if (s == char.Parse(ch2)) count2++;
            }
            int count3 = 0;
            char[] mas3 = n.ToCharArray();
            foreach (var s in mas3)
            {
                if (s == char.Parse(ch3)) count3++;
            }



            Console.WriteLine($"Число {ch1} встречается {count1}");
            Console.WriteLine($"Число {ch2} встречается {count2}");
            Console.WriteLine($"Число {ch3} встречается {count3}");

        }
    }
}
