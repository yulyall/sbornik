﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace file19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reading the contents from the file");
            StreamReader s = File.OpenText("Mytext.txt");
            int[] arr = System.IO.File.ReadAllText("Mytext.txt").Split(' ').Select(n => int.Parse(n)).ToArray();
            int local_max = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (i == 0 && i != arr.Length - 1)
                {
                    if (arr[i] > arr[i + 1])
                        local_max = arr[i];
                }
                else if (i == arr.Length - 1 && i != 0)
                {
                    if (arr[i] > arr[i - 1])
                        local_max = arr[i];
                }
                else if (arr[i - 1] < arr[i] && arr[i] > arr[i + 1])
                    local_max = arr[i];
            }
            Console.WriteLine(local_max);
            s.Close();
            Console.ReadKey();
        }
    }
}
