﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace string49
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string str = "МИНИМУМ ОБЛАКО САРДИНА   ОГНЕОПАСНО";
            Console.WriteLine(str);
            string[] words = str.Split(' ');
            string[] newWords = new string[words.Length];
            int ind = 0;
            foreach (string s in words)
            {
                string newWord = "";
                if (s.Length > 0)
                {
                    string letter = s.Substring(s.Length - 1);
                    newWord = s.Substring(0, s.Length - 1).Replace(letter, ".") + letter;
                }
                newWords[ind] = newWord;
                ind++;
            }
            Console.WriteLine(String.Join(" ", newWords));
            Console.ReadKey();
        }
    }
}
