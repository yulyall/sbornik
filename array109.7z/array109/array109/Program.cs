﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array109
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите размер массива:");
            int n = int.Parse(Console.ReadLine());
            int[] Array = new int[n];
            Random rand = new Random();
            Console.WriteLine("Исходный массив:");
            for (int i = 0; i < n; i++)
            {
                rand.Next(-100, 100);
                Console.WriteLine(i);
            }
            Console.WriteLine("Конечный массив:");
            for (int i = 0; i < n; i++)
            {
                if (i < 0)
                {
                    (i + 1, 0);
                    i++;
                }
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
