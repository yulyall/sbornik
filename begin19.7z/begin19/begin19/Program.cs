﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace begin19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x1, x2, y1, y2, P, S;
            Console.Write("Введите значение х1:");
            x1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите значение у1:");
            y1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите значение х2:");
            x2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите значение у2:");
            y2 = Convert.ToDouble(Console.ReadLine());
            P = 2 * (Math.Abs(x1 - x2) + Math.Abs(y1 - y2));
            Console.WriteLine("Периметр:" +P);
            S = Math.Abs(x1 - x2) * Math.Abs(y1 - y2);
            Console.WriteLine("Площадь:" +S);
            Console.ReadKey();
        }
    }
}
