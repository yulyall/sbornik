﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace text49
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = @"D:\\Test.txt";
            Console.WriteLine("Введiть числа (через пропуск):");
            string text = Console.ReadLine();
            string[] sArray = text.Split();
            double[] dArray = new double[text.Length];
            try
            {
                using (StreamWriter sw = new StreamWriter(path, false))
                    sw.WriteLine(text);

                double sum = 0;
                int Length = 0;

                for (int i = 0; i < sArray.Length; i++)
                {
                    dArray[i] = Convert.ToDouble(sArray[i]);

                    if (dArray[i] % 2 == 0)
                    {
                        Length++;
                        sum += dArray[i];
                    }
                }
                Console.WriteLine($"Сума чётных чисел: {sum}");

                Console.WriteLine($"Количество чётных чисел: {Length}");
                using (StreamReader sr = new StreamReader(path))
                    Console.WriteLine($"\nВмiст файла: \n{sr.ReadToEnd()}");

                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
