﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array139
{
    internal class Program
    {
        private class ItemComparer : IComparer<int[]>
        {
            public int Compare(int[] a, int[] b)
            {
                return ((a.First() <= b.First())
                    || a.Last() < b.Last()) ? -1 : 1;
            }
        }
        static void Main(string[] args)
        {
            List<int[]> points =
                new List<int[]>
                { new int[]{ 5, 5 }, new int[]{ 3, -1 },new int[] { -2, 2 } };
            points.Sort(new ItemComparer());
        }
    }
}
