﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proc49
{
    internal class Program
    {
        static int NOD(int a, int b)
        {
            return b != 0 ? NOD(b, a % b) : a;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(NOD(15, 20));
        }
    }
}
