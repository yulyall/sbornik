﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace dynamic49
{
    static void Main(string[] args)
    {
        Stack<char> charStack = new Stack<char>();
        charStack.Push('k');
        charStack.Push('Ы');
        charStack.Push('X');
        stackInfo<char>(charStack);

        Console.WriteLine("\r\ndouble type:");

        Stack<double> doubleStack = new Stack<double>();
        doubleStack.Push(11);
        doubleStack.Push(22);
        doubleStack.Push(33);
        stackInfo<double>(doubleStack);

        Console.ReadKey();
    }

    unsafe static void stackInfo<T>(Stack<T> stack) where T : unmanaged
    {
        int count = stack.Count;
        T[] array = stack.GetType().GetField("_array", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(stack) as T[];
        int elemsize = Buffer.ByteLength(array) / array.Length;

        if (count > 0)
        {
            GCHandle handle = GCHandle.Alloc(array, GCHandleType.Pinned);
            T* ptr = (T*)handle.AddrOfPinnedObject().ToPointer();
            for (int i = count - 1; i >= 0; i--)
            {
                object value = *(ptr + i);
                Console.WriteLine(value);
            }

            handle.Free();
        }
        else
        {
            Console.WriteLine("stack is empty");
        }
    }
}
