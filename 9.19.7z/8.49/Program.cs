﻿using System;
using System.Linq;

namespace _8._49
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите слово");
            string a = Console.ReadLine();
            string b = a.Substring(1, 1);
            string c = a.Substring(4, 1);
            Console.WriteLine(String.Concat(b, c));

        }
    }
}
