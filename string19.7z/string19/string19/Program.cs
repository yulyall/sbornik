﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace string19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double result_double = 0;
            int result_int = 0;
            string n = "123.34";
            if (n.Contains(".") ? double.TryParse(n, out result_double) : int.TryParse(n, out result_int))
                Console.WriteLine(result_double > result_int ? "2" : "1");
            else
                Console.WriteLine(0);
        }
    }
}
