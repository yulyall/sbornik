﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._109
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите слово:");
            string a = Console.ReadLine();
            Console.WriteLine("Введите какую букву удалить:");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("Удалена третья буква: " + a.Remove(3, 1));
            Console.WriteLine($"Удалена {b} буква: " + a.Remove(b, 1));
            Console.ReadKey();
        }
    }
}
