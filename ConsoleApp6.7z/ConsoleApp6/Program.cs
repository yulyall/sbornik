﻿using System;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10 * (-1);
            Console.WriteLine("а) х:=" + x);

           double x1 = 17.5;
            x1 = x1 * (-2);
            Console.WriteLine("б) х:=" + x1);

            int x2 = 60;
            x2 = x2 - 1;
            x2 = 0;
            Console.WriteLine("В) х:=" + x2);

            int x3 = -50;
            int k = -25;
            x3 = x3 + k;
            Console.WriteLine("г) х:=" + x3);            
        }
    }
}
