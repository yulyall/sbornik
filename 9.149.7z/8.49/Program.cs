﻿using System;
using System.Linq;

namespace _8._49
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите текст");
            string text = Console.ReadLine();
            string textNumber = "";
            for (int symbol = 0; symbol < text.Length; symbol++)
            {
                if (char.IsDigit(text[symbol]))
                    textNumber += text[symbol];
                if (textNumber.Length > 0 && !char.IsDigit(text[symbol]))
                    break;
            }
            int number = int.Parse(textNumber);
            Console.WriteLine("Число полученное из текста=" +number);
        }

    }
    
}
