﻿using System;
using System.Linq;

namespace _8._49
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите слово");
            string text = Console.ReadLine();
            bool b = true;
            int i = 0;

            while (i <= text.Length / 2)
            {
                if (text[i] != text[text.Length - 1 - i])
                    b = false;
                i++;
            }

            if (b == false)
            {
                Console.WriteLine("Это слово не палиндром");
            }
            else
            {
                Console.WriteLine("Это слово палиндром");
            }

        }

    }
    
}
