﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;

namespace file79
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int NameA = 0, NameB = 0, NameC = 0;
            try
            {
                using (StreamReader sr = new StreamReader("NameA.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }

                    NameA = Convert.ToInt32(sr);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }

            try
            {
                using (StreamReader sr1 = new StreamReader("NameB.txt"))
                {
                    string line;
                    while ((line = sr1.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }

                    NameB = Convert.ToInt32(sr1);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }

            StreamWriter ar = new StreamWriter("NameC.txt");
            {
                DirectoryInfo[] cDirs = new DirectoryInfo(@"c:").GetDirectories();
                using (StreamWriter sw = new StreamWriter("NameC.txt"))
                {
                    foreach (DirectoryInfo dir in cDirs)
                    {
                        NameC = NameA * NameB;
                        sw.WriteLine(NameC);
                    }
                }
            }
            Console.WriteLine(NameC);
        }
    }
}
