﻿using System;

namespace ConsoleApp7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите четырехзначное число:");
            int a = int.Parse(Console.ReadLine());
            int s = 0;
            while (a > 0)
            {
                s = s + a % 10;
                a = a / 10;
            }
            Console.WriteLine(s);

            int n, m = 1, b;
            Console.WriteLine("Введите четырехзначное число:");
            n = Convert.ToInt32(Console.ReadLine());
            while (n > 0)
            {
                b = n % 10;
                n = n / 10;

                m = m * b;
            }
            Console.WriteLine(m);
            Console.ReadLine();
        }
    }
}
