﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array79
{
    internal class Program
    {
        void Main()
        {
            Console.Write("Размер массива:");
            var arr = new int[int.Parse(Console.ReadLine())];
            for (int i = 0; i < arr.Length; ++i)
                arr[i] = int.Parse(Console.ReadLine());

            ShiftElements(arr);

            //выводи массив, он уже сдвинут
        }

        static void ShiftElements(int[] arr)
        {
            int prev = arr[0];
            int next;
            for (int i = 0; i < arr.Length - 1; ++i)
            {
                next = arr[i + 1];
                arr[i + 1] = prev;
                prev = next;
            }
            arr[0] = prev;
        }
    }
}
