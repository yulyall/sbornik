﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minmax19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int[] N = Enumerable.Repeat(0, 15).Select(x => r.Next(-10, 21)).ToArray();
            Console.WriteLine("Набор N:");
            Console.WriteLine(string.Join(" ", N.Select(x => x.ToString()).ToArray()));
            Console.Write("Введите целое цисло:");
            int n = int.Parse(Console.ReadLine());
            var count = N.Where(i => i < n).Count();
            Console.WriteLine(@"количество минимальных элементов из набора N, которые меньше целого числа {0} = {1} ", n, count);
            Console.ReadKey();
        }
    }
}
